# Contribs folder

Files that are submitted for shelly devices that do not fall under ShellyUSA ownership but are created to add functionality for specific usage.
